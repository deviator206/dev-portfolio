import React from 'react';
const LoggedInContext = React.createContext();

export default LoggedInContext;
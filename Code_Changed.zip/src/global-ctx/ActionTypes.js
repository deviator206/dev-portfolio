const Actions = {
    LOGIN_SUCESS:'LOGIN_SUCESS'
};

export default Actions;
